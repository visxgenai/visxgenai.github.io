from pocketflow import Node
import pandas as pd
import numpy as np
import yaml
import time
import json
from helpers import get_llm

from pathlib import Path

import json
import urllib.request
from jsonschema import validators, exceptions as js_exceptions
import concurrent.futures


llm = get_llm()

def call_llm(prompt):
    timeout_seconds = 360
    def _invoke():
        return llm.invoke([
            ("system", "You are a helpful assistant that excels at fulfilling the human's prompt"),
            ("human", prompt)
        ])

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(_invoke)
        try:
            response = future.result(timeout=timeout_seconds)
            return response.content
        except concurrent.futures.TimeoutError:
            return ''


def _fetch_json(url: str):
    with urllib.request.urlopen(url) as r:
        return json.loads(r.read().decode("utf-8"))

# --- Node Templates ---

class LoadCSVNode(Node):
    def prep(self, shared):
        return shared["csv_path"]
    def exec(self, path):
        import pandas as pd
        return pd.read_csv(path)
    def post(self, shared, prep_res, exec_res):
        print("done: LoadCSVNode")
        shared["df"] = exec_res

class AnalyzeDataNode(Node):
    def prep(self, shared):
        return shared["df"]

    def exec(self, df):
        profile = {
            "shape": df.shape,
            "columns": list(df.columns),
            "dtypes": df.dtypes.astype(str).to_dict(),
            "head": df.head(3).to_dict(orient="records"),
            "describe": df.describe(include='all').fillna('').to_dict(),
        }

        # Detect numeric outliers using z-score
        numeric_cols = df.select_dtypes(include=np.number)
        outliers = {}
        for col in numeric_cols.columns:
            z_scores = np.abs((numeric_cols[col] - numeric_cols[col].mean()) / numeric_cols[col].std(ddof=0))
            outliers[col] = df[z_scores > 3][col].tolist()

        # Simple groupings (categorical to numeric aggregations)
        groupings = {}
        cat_cols = df.select_dtypes(include=['object', 'category']).columns
        for cat_col in cat_cols:
            group_summary = {}
            for num_col in numeric_cols.columns:
                group_summary[num_col] = df.groupby(cat_col)[num_col].mean().head(3).to_dict()
            groupings[cat_col] = group_summary

        # Trends and correlations
        trends = {
            "correlations": numeric_cols.corr().to_dict()
        }

        # Column notes (flags for skewed, sparse, etc.)
        column_notes = {}
        for col in df.columns:
            notes = []
            if df[col].dtype == 'object':
                avg_len = df[col].dropna().astype(str).map(len).mean()
                if avg_len > 30:
                    notes.append("long_text")
                notes.append("text")
            if np.issubdtype(df[col].dtype, np.number):
                if df[col].nunique() < 10:
                    notes.append("low_cardinality")
                if df[col].skew() > 1:
                    notes.append("skewed")
                if df[col].std() > df[col].mean():
                    notes.append("high_variance")
            if np.issubdtype(df[col].dtype, np.datetime64):
                notes.append("temporal")
            column_notes[col] = notes

        # Detect chartable pairs (only a heuristic)
        chartable_pairs = []
        for x in df.columns:
            for y in df.columns:
                if x != y and np.issubdtype(df[y].dtype, np.number):
                    if df[x].dtype == 'object' and df[x].nunique() < 20:
                        chartable_pairs.append({"x": x, "y": y, "type": "bar"})
                    elif np.issubdtype(df[x].dtype, np.number):
                        chartable_pairs.append({"x": x, "y": y, "type": "scatter"})
                    elif np.issubdtype(df[x].dtype, np.datetime64):
                        chartable_pairs.append({"x": x, "y": y, "type": "line"})

        # Advanced visualization opportunities: heatmaps, distributions
        advanced_viz = {
            "heatmap_candidates": [],
            "histogram_candidates": []
        }

        for col1 in numeric_cols.columns:
            for col2 in numeric_cols.columns:
                if col1 != col2:
                    corr = numeric_cols[[col1, col2]].corr().iloc[0,1]
                    if abs(corr) > 0.5:
                        advanced_viz["heatmap_candidates"].append({"x": col1, "y": col2, "correlation": corr})

        for col in numeric_cols.columns:
            if df[col].nunique() > 10:
                advanced_viz["histogram_candidates"].append(col)

        return {
            "profile": profile,
            "outliers": outliers,
            "groupings": groupings,
            "trends": trends,
            "column_notes": column_notes,
            "chartable_pairs": chartable_pairs,
            "advanced_viz": advanced_viz
        }

    def post(self, shared, prep_res, exec_res):
        print("done: AnalyzeDataNode")
        shared["analysis"] = exec_res
        return "default"

class StoryIdeaNode(Node):
    def prep(self, shared):
        return shared["analysis"]

    def exec(self, analysis):
        prompt = f"""
You are a creative data journalist working on a fun and entertaining scrollytelling article.
Your task is to come up with a compelling, entertaining, **UNIQUE** and insightful story based on this dataset analysis:

### ANALYSIS
- Columns: {analysis['profile']['columns']}
- Dtypes: {analysis['profile']['dtypes']}
- Outliers: {analysis['outliers']}
- Groupings: {list(analysis['groupings'].keys())}
- Trends: {list(analysis['trends']['correlations'].keys())}
- Column Notes: {analysis.get('column_notes', {})}
- Chartable Pairs: {analysis.get('chartable_pairs', [])}
- Advanced Visualizations: {analysis.get('advanced_viz', {})}

### INSTRUCTIONS
0. Think long and hard about the analysis of the data and the insights gained from it.
1. Then: Start with a question or surprising observation from the data.
2. Then propose a brief narrative abstract (~3 sentences).
3. Propose **at least four** chapters that contain **at least three** Vega-Lite-based visualizations each that fit the chapter's narrative.
The visualizations (with chart types and which data attributes are used) should explain and enrich the argument made in the chapter. Viz_id should be a unique identifier of each visualization.
Use the "notes" attribute of each visualization to let a capable data visualization developer know if they need to be aware of anything else when actually building the Vega-Lite chart.
Only use chart types that are readily available in Vega-Lite. Use one complex chart type per chapter, restrict yourself to easier, straightforward ones for the others.
The chapters should form a narrative flow that takes up and answers/reflects the original questions/surprising observation from the data.
4. Make sure to **ONLY use quotation marks "** to denote strings/text, no other characters!
MOST IMPORTANT: Propose something novel, narrative-wise and data-wise. Think long and hard about if what you're telling about the data is actually interesting and insightful. If not, revise your proposal to make it more interesting!
5. Return your result in valid YAML format like this:

```yaml
story:
  title: ...
  abstract: ...
  chapters:
    - chapter_title: ...
      chapter_text: ...
      visualization:
        - chart_type: ...
          attributes_used: ...
          viz_id: ...
          description: ...
          notes: ...
```"""

        response = call_llm(prompt)
        print(response)
        yaml_str = response
        if("```yaml" in response):
          yaml_str = response.split("```yaml")[1].split("```")[0]

        print(yaml_str)
        return yaml.safe_load(yaml_str)

    def post(self, shared, prep_res, exec_res):
        print("done: StoryIdeaNode")

        shared.setdefault("attempts", 0)
        shared["attempts"] += 1
        shared["story_proposal"] = exec_res["story"]
        return "default"

class WriterNode(Node):
    def prep(self, shared):
        return {
            "story": shared["story_proposal"],
            "analysis": shared["analysis"]
        }

    def exec(self, context):
        story = context["story"]
        analysis = context["analysis"]

        title = story.get("title", "Untitled")
        abstract = story.get("abstract", "")
        chapters = story.get("chapters", [])

        prompt = f"""
You are a skilled data journalist writing an editorial-style article. The story should be engaging, insightful, and structured like a modern scrollytelling feature on The Pudding or the New York Times.

Your task is to write the full article as Markdown, using the following information:

# Title:
{title}

# Abstract:
{abstract}

# Chapters Outline:
{yaml.dump(chapters)}

# Data Summary:
{yaml.dump(analysis)}

## Guidelines:
- Write one unified narrative, not a set of disjointed sections.
- Avoid making each chapter feel like an independent article.
- Flow logically from one section to the next — use transitions. DO NOT write "Transition: " to lead-in to the actual transition.
- Use clear section headers sparingly and only where natural.
- Highlight insights using blockquotes where natural.
- Insert the specific `viz_id` (from the chapters outline) where a specific chart that you're referring to in the chapter should be placed. DO NOT surround the ID with anything else or add any Markdown to it!
- DO NOT add the visualization captions to the text.
- Make the tone curious, human, unpretentious and engaging.
- Tie the conclusion back to the introduction or key question.

IMPORTANT: Only return clean Markdown. No code blocks, no explanations, no metadata.
"""
        markdown_article = call_llm(prompt)
        return markdown_article

    def post(self, shared, prep_res, exec_res):
        print("done: WriterNode")
        shared["story_markdown"] = exec_res
        return "default"

class HTMLWriterNode(Node):
    def prep(self, shared):
        return shared["story_markdown"]

    def exec(self, markdown_text):
        from markdown import markdown

        html_content = markdown(markdown_text)

        return {
            "html": html_content
        }

    def post(self, shared, prep_res, exec_res):
        print("done: HTMLWriterNode")

        full_html = f"""
<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"UTF-8\">
  <title>{shared['story_proposal'].get('title', 'Story')}</title>
  <style>STYYLE</style>
</head>
<body>
<main class="container">
  {exec_res['html']}
  </main>
    <script>
      VEGASTOYLE
    </script>
</body>
</html>
"""
        shared["final_html"] = full_html.strip()



class VizNode(Node):
    def prep(self, shared):
        return {
            "html": shared["final_html"],
            "story": shared["story_proposal"],
            "analysis": shared["analysis"]
        }

    def exec(self, context):
        import pandas as pd
        html = context["html"]
        story = context["story"]
        analysis = context["analysis"]
        df = pd.read_csv("dataset.csv")

        # Gather all visualization specs
        visualizations = []
        for chapter in story.get("chapters", []):
            visualizations.extend(chapter.get("visualization", []))

        # Split html at VISUALIZATION markers
        sections = html.split("<visualization>")
        completed_html = sections[0]

        specs = []

        for i in range(1, len(sections)):
            if i - 1 >= len(visualizations):
                continue
            viz = visualizations[i - 1]
            print(f"working on visualization {i}/{len(visualizations)}")

            print(viz)

            tries = 0
            while tries < 3:
                prompt = f"""
    You are a data visualization developer. You are aware of all the best practices for teasing out the maximum
    insight from a data visualization.

    Write a Vega-Lite spec that renders a chart of type:
    {viz.get('chart_type')}
    using these attributes from the data:
    {viz.get('attributes_used')}
    following this description:
    {viz.get('description', '')}

    Plus, here's some notes from the writer about this chart that might be helpful:
    {viz.get('notes', '')}

    Write a Vega-Lite spec that:
    - Loads the dataset from "https://raw.githubusercontent.com/demoPlz/mini-template/main/studio/dataset.csv" via the Vega-Lite data URL.
    - Make sure that all "marks" are one of: "area", "bar", "circle", "line", "point", "rect", "rule", "square", "text", "tick", or "geoshape"
    - Make ABSOLUTELY SURE to use CORRECT Vega-Lite spec code. Change the chart type if necessary so it's actually working in vega-lite!
    - Provide vega-lite tooltips in the spec if possible
    - Use: width: "container", height: 600 (or higher if the visualization needs to be taller)
    - if you're using vega-lite color schemes, be sure to pick subtle and subdued ones
    - Rephrase the chart's description to explain the main insight that can be gained from it and fill this into the "description" property of the vega-lite spec

    Make sure to use the correct columns from the data. Here's a list of all columns:
    {analysis.get('profile').get('columns')}

    IMPORTANT:
    Only return a pure JSON object containing the vega-lite specification! No backticks, no explaination, nothing else!
    """

                chart_block = call_llm(prompt)
                time.sleep(15)  # don't overwhelm the API!
                if chart_block.startswith("```"):
                    chart_block = chart_block.strip("`").split("javascript")[-1].strip()
                    chart_block = chart_block.strip("`").split("json")[-1].strip()
                
                # check if we have valid json:
                try:
                    spec = json.loads(chart_block)
                    print("got valid json")
                    print(spec)

                    # check for vega-lite validity:
                    schema_url = spec.get("$schema")
                    if not schema_url:
                        raise ValueError("Spec must contain a `$schema` property.")

                    schema = _fetch_json(schema_url)

                    # Let jsonschema choose the correct draft automatically.
                    Validator = validators.validator_for(schema)
                    # IMPORTANT: do NOT call Validator.check_schema(schema)
                    validator = Validator(schema)
                    validator.validate(spec)  # raises ValidationError if the spec is invalid

                    viz_id = viz.get('viz_id', i)

                    completed_html += f'''
                    <figure id="vis_{viz_id}">
                    <div></div>
                    <figcaption>{spec.get('description', '')}</figcaption>
                    </figure>{sections[i]}
                    '''

                    specs.append({'spec': chart_block, 'num': i, 'viz_id': viz_id})

                    # stop the loop:
                    tries = 99

                except Exception as e:
                    print(f"Invalid JSON: {e}")
                    tries = tries + 1

        # Inject Vega libraries into <head>
        head_close = completed_html.find("</head>")
        libs = """
<script src=\"https://cdn.jsdelivr.net/npm/vega@5\"></script>
<script src=\"https://cdn.jsdelivr.net/npm/vega-lite@5\"></script>
<script src=\"https://cdn.jsdelivr.net/npm/vega-embed@6\"></script>
"""
        final_html = completed_html[:head_close] + libs + completed_html[head_close:]

        final_specs = ""
        for spec in specs:
            final_specs += f"""
        renderSpec("#vis_{spec.get('viz_id')}", {spec.get('spec')})
        """

        Path('final_specs.tmp').write_text(final_specs, encoding="utf-8")


        # add scripts:
        body_close = final_html.find("</body>")
        final_html = f"""
{final_html[:body_close]}
<script>
 function renderSpec(target, spec) {{
        const base = {{ width: "container", height: 600 }};
        const merged = Object.assign({{}}, spec, vegaConfig || {{}}, base);
        vegaEmbed(target, merged, {{ renderer: "svg", actions: false }});
        }}

setTimeout(() => {{{''.join(final_specs)}
}}, 1000)</script> 
{final_html[body_close:]}
        """

        return final_html

    def post(self, shared, prep_res, exec_res):
        shared["final_html"] = exec_res


class ChartReviewNode(Node):
    def prep(self, shared):
        return {
            "story": shared["story_proposal"],
            "df": shared["df"]
        }

    def exec(self, context):
        import random
        story = context["story"]
        df = context["df"]

        review_payload = []
        for i, chapter in enumerate(story.get("chapters", [])):
            for j, viz in enumerate(chapter.get("visualization", [])):
                description = viz.get("description", "")
                sample = df.sample(min(10, len(df))).to_dict(orient="records")
                review_payload.append({
                    "index": f"chapter_{i}_viz_{j}",
                    "description": description,
                    "sample_data": sample
                })

        prompt = f"""
You are a chart editor. For each chart description and data sample below, review whether a Vega-Lite chart based on it would be:
- Empty or almost empty
- Overwhelming (too many labels, clutter)
- Misaligned with the intent described

Return a JSON list with index, status ("pass" or "revise"), and reason if status is revise.

{yaml.dump(review_payload)}
"""

        result = call_llm(prompt)
        return result

    def post(self, shared, prep_res, exec_res):
        print("done: ChartReviewNode")
        shared["chart_review"] = exec_res
        return "default"


class CSSNode(Node):
    def prep(self, shared):
        return shared["final_html"]

    def exec(self, final_html):
        prompt = f"""
        You are a web designer for a modern, high-end digital news publication like The New York Times or The Pudding.
        Based on the following HTML content (first 1000 chars shown):

        ---
        {final_html[:1000]}
        ---

        Pick a light, pleasing, friendly, unusual color palette. Extract foreground and background colors. They should have a proper level of contrast.

        Generate elegant, responsive CSS that gives the article a clean editorial layout with:
        - Readable sans-serif fonts for body text, with larger than usual font-size
        - Cool, fun, unusual sans-serif fonts for headings that fit with the body text font
        - also make sure to import fonts in your CSS if you're using something like Google Fonts for it
        - Apply background color to html, body and .container
        - Apply foreground color to text, other elements if necessary
        - Centered article container with padding and display: flex. Everything should be centered horizontally.
        - All regular HTML tags (h1 ... h5, p, blockquote, ...) should have a width of 800px.
        - <figure> elements should be at least 1000px wide with a max-width of 1200px and top-margins of 2.5rem and bottom-margins of 5rem.
        - <figcaption> elements should have a suitable styling as well
        - Nicely spaced section breaks and paragraph rhythm
        - Styling for blockquotes
        - Intro styling for opening <h1> and <p> elements
        - Make sure everything is WCAG AA-compatible

        IMPORTANT:
        - Only return raw CSS (no explanations or markdown formatting)
        - Target modern browsers (CSS Grid/Flexbox allowed)
        """

        css_styles = call_llm(prompt)
        if css_styles.startswith("```"):
          css_styles = css_styles.strip("`").split("css")[-1].strip()


        vegaprompt = f"""
        You are a data visualization designer for a modern, high-end digital news publication like The New York Times or The Pudding.
        Based on the following CSS:

        ---
        {css_styles[:1000]}
        ---

        Create a fitting vega-lite configuration options object for styling the chart.
        - set background to a suitable color from the CSS above.
        - also create a config property to style properties like titleColor, titleFont, gridColor, domainColor, labelColor, labelFont, tickColor to fit the color scheme from the CSS.

        IMPORTANT:
        - Only return a raw JavaScript object in the format:
        const vegaConfig = {{
          KEY: VALUE,
          ...,
        }}
        - DO NOT return $schema, explanations, ticks, markdown formatting or anything like that
        """

        vega_styles = call_llm(vegaprompt)
        if vega_styles.startswith("```"):
          vega_styles = vega_styles.strip("`").split("javascript")[-1].strip()

        return {
            "css": css_styles.strip(),
            "vega_style": vega_styles.strip(),
            "html": final_html
        }

    def post(self, shared, prep_res, exec_res):
        print("done: CSSNode")

        sections = exec_res["html"].split("STYYLE")
        subsections = sections[1].split("VEGASTOYLE")

        full_html = f"""
        {sections[0]}
        {exec_res['css']}
figure div {{
        width: 100% !important;
}}

figcaption {{
  font-style: italic;
}}
        {subsections[0]}
        {exec_res['vega_style']}
        {subsections[1] if len(subsections) > 1 else ''}

"""
        shared["final_html"] = full_html.strip()



class FinalEditingNode(Node):
    def prep(self, shared):
        Path("preFinal.html").write_text(shared["final_html"], encoding="utf-8")

        return {
            "html": shared["final_html"],
            "story_summary": shared["story_proposal"],
            "data_summary": shared["analysis"]
        }

    def exec(self, context):
        prompt = f'''
You are a final-stage editorial assistant for a data journalism scrollytelling article.
Here is the full HTML output, a story summary, and a dataset analysis.

Your job is to:
- Smooth out narrative transitions between paragraphs
- Refine awkward sentences for flow and clarity
- Check and fix chart figure alignment, sizing hints, or captions
- Optionally suggest improvements to chart placements or visual context
- Make the entire page feel more like a finished, professional publication
- Do NOT remove or replace <script> blocks or any embedded Vega charts
- Leave all <style> tweaks in place but feel free to append or modify for better presentation

ONLY RETURN the modified HTML.

---

### STORY SUMMARY:
{yaml.dump(context["story_summary"])}

### ANALYSIS:
{yaml.dump(context["data_summary"])}

### CURRENT HTML:
{context["html"]}
'''
        result = call_llm(prompt)

        return {
            "html": result
        }

    def post(self, shared, prep_res, exec_res):
        print("done: FinalEditingNode")

        full_html = exec_res["html"]
        shared["final_html"] = full_html.strip()