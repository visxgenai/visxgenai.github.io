from pocketflow import Flow
from nodes import LoadCSVNode, AnalyzeDataNode, StoryIdeaNode, WriterNode, HTMLWriterNode, CSSNode
from viznode import VizNode

def create_story_flow():
    """Do some data journalism"""
    # Create nodes
    load = LoadCSVNode()
    analyze = AnalyzeDataNode()
    idea = StoryIdeaNode()
    writer = WriterNode()
    viz = VizNode()
    webdev = HTMLWriterNode()
    css = CSSNode()

    # --- Connect Nodes in Flow ---
    load >> analyze >> idea >> writer >> webdev >> css >> viz
    
    # Create flow starting with load data node
    return Flow(start=load)

story_flow = create_story_flow()