from flow import create_story_flow
from pathlib import Path

class Agent:
    def __init__(self):
        self.workflow = None

    def initialize(self):
        self.workflow = create_story_flow()

    def process(self):
        if self.workflow is None:
            raise RuntimeError("Agent not initialised. Call initialize() first.")

        # invoke the workflow
        shared = {
            "csv_path": "./dataset.csv"
        }
        self.workflow.run(shared)

        result = shared["final_html"]

        Path("output.html").write_text(result, encoding="utf-8")

        # return the result
        return shared