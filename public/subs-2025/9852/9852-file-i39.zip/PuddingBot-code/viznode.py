import json
import re
import time
from pathlib import Path

import yaml
import pandas as pd
from jsonschema import validators
from pocketflow import Node

from helpers import get_llm

from pathlib import Path

import json
import urllib.request
from jsonschema import Draft7Validator, validators, exceptions as js_exceptions
import requests
import concurrent.futures
import altair




llm = get_llm()

def call_llm(prompt):
    timeout_seconds = 360
    def _invoke():
        return llm.invoke([
            ("system", "You are a helpful assistant that excels at fulfilling the human's prompt"),
            ("human", prompt)
        ])

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(_invoke)
        try:
            response = future.result(timeout=timeout_seconds)
            return response.content
        except concurrent.futures.TimeoutError:
            return ''


def _fetch_json(url: str):
    with urllib.request.urlopen(url) as r:
        return json.loads(r.read().decode("utf-8"))

class VizNode(Node):
    def prep(self, shared):
        return {
            "html": shared["final_html"],
            "story": shared["story_proposal"],  # may be dict or YAML string (possibly wrapped in <yaml> tags)
            "analysis": shared["analysis"],
        }

    def _parse_story(self, story_raw):
        """
        Accepts:
          - dict already shaped like {"story": {...}} or {"chapters": [...]}
          - YAML string (optionally wrapped as <yaml>...</yaml>)
        Returns normalized dict: {"story": {"chapters": [...]}}
        """
        if isinstance(story_raw, dict):
            story = story_raw
        else:
            text = str(story_raw).strip()
            # strip <yaml> wrappers if present
            text = re.sub(r"^\s*<yaml>\s*", "", text, flags=re.IGNORECASE)
            text = re.sub(r"\s*</yaml>\s*$", "", text, flags=re.IGNORECASE)
            story = yaml.safe_load(text) or {}

        # normalize: we want story dict under "story"
        if "story" in story and isinstance(story["story"], dict):
            return story
        else:
            return {"story": story}

    def _chapters(self, story_dict):
        story = story_dict.get("story") or {}
        chapters = story.get("chapters") or []
        return chapters if isinstance(chapters, list) else []

    def _viz_by_id(self, story_dict):
        out = {}
        for ch in self._chapters(story_dict):
            for viz in (ch.get("visualization") or []):
                if isinstance(viz, dict) and viz.get("viz_id"):
                    out[str(viz["viz_id"]).strip()] = viz
        return out

    def _columns_list(self, analysis):
        try:
            cols = analysis.get("profile", {}).get("columns", [])
            if isinstance(cols, (list, tuple)):
                return list(cols)
            return []
        except Exception:
            return []

    def _ensure_head_injection(self, html, libs_block):
        # inject libs right before </head> if present, else at top
        head_close = html.lower().find("</head>")
        if head_close != -1:
            return html[:head_close] + libs_block + html[head_close:]
        # no <head>? create a minimal one at the top
        return f"<head>{libs_block}</head>{html}"

    def _ensure_body_append(self, html, script_block):
        # append before </body> if present, else at end
        body_close = html.lower().rfind("</body>")
        if body_close != -1:
            return html[:body_close] + script_block + html[body_close:]
        return f"{html}{script_block}"

    def _llm_make_spec(self, viz, columns_list):
        # first-attempt prompt: generate a new spec
        prompt = f"""
You are a data visualization developer following Vega-Lite best practices.

Write a Vega-Lite spec that renders a chart of type:
{viz.get('chart_type')}

Use these attributes from the data:
{viz.get('attributes_used')}

Follow this description:
{viz.get('description','')}

Notes from the writer:
{viz.get('notes','')}

Constraints:
- Load the dataset via Vega-Lite data URL: "https://raw.githubusercontent.com/demoPlz/mini-template/main/studio/dataset.csv"
- Mark must be one of: "area","bar","circle","line","point","rect","rule","square","text","tick","geoshape"
- Use correct, working Vega-Lite v5 JSON (no JS, no comments)
- only override the domain of a scale if ABSOLUTELY necessary
- use as little ticks as possible and turn off the axis grid
- Provide tooltips when reasonable
- Use width: "container" and height: 600 (or taller if needed)
- Prefer subtle, subdued color schemes when using vega-lite schemes
- Add a concise human-readable summary of the main insight in the spec's top-level "description"

Use correct column names. Available columns:
{columns_list}

IMPORTANT: Return ONLY the pure JSON object (no backticks, no prose).
"""
        result = call_llm(prompt)
        print(result)

        return result

    def _llm_fix_spec(self, failing_spec_json, error_message, viz, columns_list):
        # repair prompt: keep spec, fix the errors only
        prompt = f"""
You are fixing a Vega-Lite spec. Do not invent a brand-new chart unless necessary.
You must primarily *edit the given spec* to resolve the error(s) while preserving intent.

Original intent:
- chart_type: {viz.get('chart_type')}
- attributes_used: {viz.get('attributes_used')}
- description: {viz.get('description','')}
- notes: {viz.get('notes','')}

Dataset columns available:
{columns_list}

Current (failing) spec JSON:
{failing_spec_json}

Validator error to fix:
{error_message}

Requirements:
- Keep using data URL "https://raw.githubusercontent.com/demoPlz/mini-template/main/studio/dataset.csv"
- Ensure the "mark" is one of: "area","bar","circle","line","point","rect","rule","square","text","tick","geoshape"
- The output MUST be valid Vega-Lite v5 JSON
- Add or preserve width: "container", height: 600 (or appropriate)
- Include useful tooltips where reasonable
- Keep/adjust the top-level "description" as a human-readable insight summary

IMPORTANT: Return ONLY the pure JSON object (no backticks, no prose).
"""
        return call_llm(prompt)

    def _extract_json(self, txt):
        # strip code fences if the model sent any
        t = txt.strip()
        if t.startswith("```"):
            t = t.strip("`")
            # common patterns ```json ...``` or ```javascript ...```
            parts = re.split(r"(json|javascript|js)\s", t, flags=re.IGNORECASE, maxsplit=1)
            if len(parts) > 2:
                t = parts[-1].strip()
        return t

    def _validate_vegalite_schema(self, spec):
        try:
            altair.Chart.from_json(spec)
            return
        except Exception as e:
            return e

    def exec(self, context):
        import jsonschema  # ensure available
        html = context["html"]
        story_raw = context["story"]
        analysis = context["analysis"]

        story = self._parse_story(story_raw)
        viz_map = self._viz_by_id(story)
        columns_list = self._columns_list(analysis)

        # Collect render calls and placeholder replacements
        render_calls = []
        replacements = {}

        print(story)
        print(viz_map)
        print(viz_map.keys())

        for viz_id in viz_map.keys():
            print(f"Working on visualization id='{viz_id}'")

            viz = viz_map[viz_id]

            tries = 0
            last_err = None
            current_spec_text = None

            parse_spec = ""
            spec = ""

            while tries < 3:
                try:
                    if current_spec_text is None:
                        # first attempt: make a fresh spec
                        raw = self._llm_make_spec(viz, columns_list)
                    else:
                        # repair pass: send failing spec + error
                        raw = self._llm_fix_spec(current_spec_text, str(last_err), viz, columns_list)
                    
                    print(raw)

                    time.sleep(2)  # be gentle to the API
                    raw = self._extract_json(raw)
                    spec = json.loads(raw)

                    # minimal default dimensions if missing; we still validate structure
                    spec.setdefault("width", "container")
                    spec.setdefault("height", 600)
                    spec.setdefault("$schema", "https://vega.github.io/schema/vega-lite/v5.json")

                    parse_spec = spec
                    spec = raw
                    print(f"""spec to test:
                    
                    
                    """)
                    print(spec)
                    print(f"""
                    
                    
                    
                    """)


                    validation_result = self._validate_vegalite_schema(spec)

                    if validation_result is not None:
                      raise ValueError(validation_result)
                    
                    print("Vega-Lite spec validated ✅")

                    # Build figure (caption from spec.description if present)
                    caption = parse_spec.get("description", "") or ""
                    fig_html = f"""<figure id="vis_{viz_id}" class="vega-figure">
<div class="vega-target"></div>
{f"<figcaption>{caption}</figcaption>" if caption else ""}
</figure>"""

                    replacements[viz_id] = fig_html

                    # Store render call (embed later)
                    render_calls.append({
                        "viz_id": viz_id,
                        "spec": spec,  # keep as str; we’ll dump once
                    })
                    break  # success

                except Exception as e:
                    last_err = e
                    current_spec_text = raw if 'raw' in locals() else None
                    print(f"Spec attempt failed for {viz_id}: {e}")
                    tries += 1

            if tries >= 3 and not viz_id in replacements:
              # use the last try - better than nothing
              caption = parse_spec.get("description", "") or ""
              fig_html = f"""<figure id="vis_{viz_id}" class="vega-figure">
<div class="vega-target"></div>
{f"<figcaption>{caption}</figcaption>" if caption else ""}
</figure>"""

              replacements[viz_id] = fig_html

              render_calls.append({
                "viz_id": viz_id,
                "spec": spec
              })

        # Replace placeholders in HTML
        completed_html = html
        for rep in replacements:
          replacement = replacements[rep]

          viz_placement = completed_html.find(rep)
          print(f"found {rep} at {viz_placement}")
          completed_html = completed_html[:viz_placement] + replacement + completed_html[viz_placement + len(rep):]

        print(completed_html)

        # Inject Vega libs once
        libs = """
<script src="https://cdn.jsdelivr.net/npm/vega@5"></script>
<script src="https://cdn.jsdelivr.net/npm/vega-lite@5"></script>
<script src="https://cdn.jsdelivr.net/npm/vega-embed@6"></script>
"""
        completed_html = self._ensure_head_injection(completed_html, libs)

        # Build one big script that renders all specs
        # Dump specs as a JS array to avoid string concat hazards
        specs_array = []
        for rc in render_calls:
            specs_array.append({
                "target": f"#vis_{rc['viz_id']}",
                "spec": rc["spec"],
            })

        specs_js = json.dumps(specs_array, ensure_ascii=False)
        specs_js = re.sub('\n', '', specs_js)

        render_script = f"""
<script>
(function() {{
  function renderSpec(target, spec) {{
    try {{
      var base = {{ width: "container", height: 600 }};
      var merged = {{...spec, ...base}};
      // vegaConfig may or may not exist in page scope
      if (typeof vegaConfig === "object" && vegaConfig) {{
        merged = {{...spec, ...vegaConfig, ...base}};
      }}
      vegaEmbed(target + " .vega-target", merged, {{ renderer: "svg", actions: false }})
        .catch(function(err) {{
          console.error("vegaEmbed error for", target, err);
        }});
    }} catch (e) {{
      console.error("renderSpec error for", target, e);
    }}
  }}

  var queue = {specs_js};
  // Slight delay to allow DOM to settle
  setTimeout(function() {{
    queue.forEach(function(item) {{
      renderSpec(item.target, JSON.parse(item.spec));
    }});
  }}, 50);
}})();
</script>
"""
        print(render_script)
        final_html = self._ensure_body_append(completed_html, render_script)

        # Optionally persist render calls (useful for debugging/pipeline)
        try:
            Path("final_specs.json").write_text(json.dumps(specs_array, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

        return final_html

    def post(self, shared, prep_res, exec_res):
      print("Done: VizNode")
      shared["final_html"] = exec_res