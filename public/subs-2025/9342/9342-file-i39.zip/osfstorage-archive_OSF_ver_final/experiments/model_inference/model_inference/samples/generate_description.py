import os
import base64
import requests
from dotenv import load_dotenv

dotenv_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".env"))
load_dotenv(dotenv_path=dotenv_path)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
	raise ValueError("OPENAI_API_KEY is not set in the environment variables.")


MODEL = "gpt-5-2025-08-07"

# test_type = "ggr"
# test_type = "holf"
# test_type = "holf2"
# test_type = "calvi-standard"
# test_type = "calvi-trick"
test_type = "vlat"


STRICT_SYSTEM_PROMPT = """
You are an assistant that describes the visual structure of chart images.

Rules:
- Output must be one paragraph, less than 100 words, in English.
- Follow the template structure: chart type & title; axes; marks; legend; gridlines & ticks; overall styling.
- Allowed:
  • Chart type (bar chart, line chart, scatter plot, pie chart, etc.).
  • Title text (quote exactly as written).
  • Axis titles and units, if present (no tick values).
  • Category labels (list exactly as shown).
  • Marks: shape (bars, slices, dots, lines), outline/fill style, colors.
  • Legend: state if present and list labels, otherwise state absence.
  • Gridlines: mention orientation (horizontal/vertical/both).
  • Tick marks: acknowledge existence, not values.
  • Overall styling (monochrome, bold outline, shading, etc.).
- Forbidden:
  • Reporting or paraphrasing any tick values, data values, or scale values.
  • Counts of marks, comparisons, relative size, proportions, trends, correlations, distributions.
  • Words like evenly, uniformly, represent, correspond, show, increase, decrease, cluster, spread, dense, scattered, outlier, variability.
  • Any interpretation of meaning.
- Return only the paragraph, no lists or bullets.
"""

txt_path = os.path.join(os.path.dirname(__file__), test_type + ".txt")
with open(txt_path, "r", encoding="utf-8") as f:
    img_names = [line.strip() for line in f if line.strip()]


img_dir = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "..", "downloaded_data", "images", test_type)
)

desc_dir = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "..", "downloaded_data", "descriptions", test_type)
)
os.makedirs(desc_dir, exist_ok=True)




def gpt5_generate_description(image_path, STRICT_SYSTEM_PROMPT):
    with open(image_path, "rb") as img_f:
        img_base64 = base64.b64encode(img_f.read()).decode("utf-8")

    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }
    data = {
        "model": "gpt-5-2025-08-07",
        "messages": [
            {"role": "system", "content": STRICT_SYSTEM_PROMPT},
            {"role": "user", "content": [
                {"type": "text", "text": "Describe the attached chart under the rules."},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_base64}"}}
            ]}
        ],
        "max_completion_tokens": 3000,
    }

    r = requests.post(url, headers=headers, json=data, timeout=60)
    
    try:
        j = r.json()
    except Exception:
        print(f"[ERROR] Non-JSON response: {r.text[:500]}")
        return None
    

    if r.status_code != 200:
        print(f"[HTTP {r.status_code}] {j}")
        return None

    # print(j)

    content = j["choices"][0]["message"]["content"]
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for p in content:
            t = p.get("text") or p.get("content")
            if isinstance(t, str):
                parts.append(t)
        return "\n".join(parts).strip()
    return ""



# url = "https://api.openai.com/v1/chat/completions"
# headers = {
#     "Authorization": f"Bearer {OPENAI_API_KEY}",
#     "Content-Type": "application/json",
# }

# def gpt5_generate_description(image_url, prompt, temperature=0, top_p=1.0, max_tokens=150):
#     user_content = [{"type": "text", "text": prompt}]
#     # if incontext_examples:
#     #     for ex in incontext_examples:
#     #         if "image_url" in ex:
#     #             user_content.append({
#     #                 "type": "image_url",
#     #                 "image_url": {"url": ex["image_url"]}
#     #             })
#     if image_url:
#         user_content.append({
#             "type": "image_url",
#             "image_url": {"url": image_url}
#         })

#     data = {
#         "model": MODEL,
#         "messages": [
#             {"role": "system", "content": "You are a helpful assistant."},
#             {"role": "user", "content": user_content}
#         ],
#         # "max_tokens": max_tokens,
#         "max_completion_tokens": max_tokens,
#         "temperature": temperature,
#         "top_p": top_p,
#     }

#     r = requests.post(url, headers=headers, json=data, timeout=60)
#     if r.status_code == 200:
#         j = r.json()
#         return j["choices"][0]["message"]["content"]
#     elif r.status_code == 429:
#         print("Rate limit exceeded")
#         return None
#     else:
#         raise RuntimeError(f"HTTP {r.status_code}: {r.text}")



for name in img_names:
    img_path = os.path.join(img_dir, name)
    if os.path.exists(img_path):
        print(f"Processing {img_path}")
        description = gpt5_generate_description(img_path, STRICT_SYSTEM_PROMPT)
        if description:
            txt_name = os.path.splitext(name)[0] + ".txt"
            txt_path = os.path.join(desc_dir, txt_name)
            with open(txt_path, "w", encoding="utf-8") as f:
                f.write(description)
            print(f"Saved description for {name}")
        else:
            print(f"Failed to get description for {name}")
    else:
        print(f"Not found: {img_path}")