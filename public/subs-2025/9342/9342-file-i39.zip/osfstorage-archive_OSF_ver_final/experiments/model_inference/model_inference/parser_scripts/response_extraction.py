

task_description = "Please read the following example. Then extract the answer from the model response and type it at the end of the prompt."