import time
from .data_utils import DataUtils
from .model_utils import ModelUtils
import pandas as pd
import os


class Benchmark:
    def __init__(self, agentType, testType, promptType, numTrials=10, timeout=0, temperature=1, topP=0.8, prompt_mode="paper"):
        self.agentType = agentType
        self.testType = testType
        self.promptType = promptType
        self.numTrials = numTrials
        self.timestamp = int(time.time() * 1000)
        self.timeout = timeout

        self.instructions = DataUtils.fetch_instructions(self.testType)


        ########## local for easy run, avoid internet problems
        # instructions_path = os.path.join(
        #     os.path.dirname(__file__),
        #     "..", "..", "..", "..",
        #     "downloaded_data", "instructions", f"{self.testType}_instructions.txt"
        # )
        # instructions_path = os.path.abspath(instructions_path)
        # if os.path.exists(instructions_path):
        #     with open(instructions_path, "r", encoding="utf-8") as f:
        #         self.instructions = f.read()
        # else:
        #     print(f"Warning: instructions file not found: {instructions_path}")
        #     self.instructions = ""
        ########## local for easy run, avoid internet problems


        self.process_func = ModelUtils(self.agentType, temperature, topP).process_image
        self.temperature = temperature
        self.topP = topP

        # added by ykc
        self.description = ""
        self.results = []  # Store results for later saving
        self.prompt_mode = prompt_mode
        # added by ykc

        



    def has_gpt4v_returned_invalid(self, row):
        invalid_df = pd.read_csv("/Users/arnav/Desktop/contextvis/vlm-datavis-benchmark/analysis/gpt4v_invalid_prompt_jan19.csv")
        is_question = (row["question"] + " & " + row["image_file"])  not in invalid_df["question_image"].values
        # is_prompt_type = self.promptType not in invalid_df["promptType"].values
        return is_question #and is_image # and is_prompt_type

    def run(self):
        df = DataUtils.fetch_questions(self.testType)

        if (self.testType == "ggr" or 
            self.testType == "vlat" or 
            self.testType == "holf" or 
            self.testType == "holf2" or
            self.testType == "calvi-trick" or
            self.testType == "calvi-standard"):
            txt_path = os.path.join(os.path.dirname(__file__), "samples", f"{self.testType}.txt")
            with open(txt_path, "r", encoding="utf-8") as f:
                valid_imgs = set(line.strip() for line in f if line.strip())
            df = df[df["image_file"].isin(valid_imgs)]


        print(f"Currently on test {self.testType} for agent: {self.agentType} for top_p={self.topP}, t={self.temperature}.")

        # if (self.timeout > 0):
        #     for i, _ in df.iterrows():
        #         # if self.has_gpt4v_returned_invalid(row):
        #         #    continue
        #         # if (i < 286):
        #         #     continue
        #         print(f"INDEX {i}")
        #         #idx = int(len(df) - 1 - i)
        #         row = df.iloc[i]
        #         self.benchmark_question(row)
        # else:
        #     df.apply(self.benchmark_question, axis=1)

        if (self.timeout > 0):
            for i, row in df.iterrows():
                # if self.has_gpt4v_returned_invalid(row):
                #    continue
                # if (i < 286):
                #     continue
                print(f"INDEX {i}")
                #idx = int(len(df) - 1 - i)
                # row = df.iloc[i]
                self.benchmark_question(row)
        else:
            df.apply(self.benchmark_question, axis=1)

        DataUtils.save_file(self.results, self.prompt_mode, self.agentType, self.testType)


    def benchmark_question(self, row):

        # added by ykc
        image_file = row["image_file"] if "image_file" in row else os.path.basename(row["image_link"])
        desc_file = os.path.splitext(image_file)[0] + ".txt"
        desc_path = os.path.join(
            os.path.dirname(__file__),
            "..", "..", "..", "..",
            "downloaded_data", "descriptions", self.testType, desc_file
        )
        desc_path = os.path.abspath(desc_path)

        if os.path.exists(desc_path):
            with open(desc_path, "r", encoding="utf-8") as f:
                description = f.read()
        else:
            description = ""
            print(f"Warning: description file not found: {desc_path}")
        self.description = "Chart Description: \n" + description + "\n Task:"
        # print("Description:", description)
        # added by ykc


        prompt, incontext_examples, instructions_part, description_part = self.create_prompt_from_row(row)
        # print("="*20 + " PROMPT " + "="*20)
        # print(prompt)
        # print("="*48)

        textInput = row["text_input_type"]

        print("="*20 + " Question Type " + "="*20)
        print(textInput)
        print("="*48)


        # test for image link
        # img = DataUtils.get_image(row["image_link"])
        # if img is not None:
        #     img_dir = r"D:\models\images"
        #     img_path = os.path.join(img_dir, row["image_file"])
        #     img.save(img_path)


        for i in range(self.numTrials):
            generated_text = self.process_func(row["image_link"], prompt, incontext_examples=incontext_examples)
            # print(f"Benchmark Trial {i}. Question index: {row.name}. Question: {row['question']}. Generated text: {generated_text}")
            print(f"Benchmark Trial {i}. Question index: {row.name}. Prompt: {prompt}. Generated text: {generated_text}.")
            


            # add to test result file
            # with open(r"D:\models\testResult.txt", "a", encoding="utf-8") as f:
            #     f.write(f"{row['image_file']}\t{row['question']}\t{generated_text}\n")

            data = {
                "question": row["question"],
                "prompt": prompt,
                "agentType": self.agentType,
                "testType": self.testType,
                "correctAnswer": row["correct_answer"],
                "agentResponse": generated_text,
                "imageFile": row["image_file"],
                "imageLink": row["image_link"],
                "taskCategory": "",
                "multipleChoice": [],
                "metadataLink": "",
                "timestamp": self.timestamp,
                "textInput": textInput,
                "promptType": self.promptType,
                "temperature": self.temperature,
                "topP": self.topP
            }

            generate_results = {
                "instructions": instructions_part,
                "description": description_part,
                "question": row["question"],
                "image_file": row["image_file"],
                "item_id": row["question"]+row["image_file"],
                "agent_type": self.agentType,
                "agent_response": generated_text,
                "correct_answer": row["correct_answer"],
                "test_type": self.testType,
                "is_correct": int(row["correct_answer"] == generated_text)
            }

            self.results.append(generate_results)
            # DataUtils.post_data(data)

            if self.timeout > 0:
                time.sleep(self.timeout)

        return data


    def create_prompt_from_row(self, row):
        textInput = row["text_input_type"]
        question = row["question"]

        description_part = self.description
        instructions_part = self.instructions

        if hasattr(self, "prompt_mode"):
            if self.prompt_mode == "no_instruction":
                description_part = ""
                instructions_part = ""
            elif self.prompt_mode == "with_description":
                instructions_part = ""
            elif self.prompt_mode == "paper":
                description_part = ""
            elif self.prompt_mode == "question_only":
                description_part = ""
                instructions_part = ""

        if textInput == "open_ended_question":
            # restriction = "Your answer must be numerical and rounded to 3 significant figures."
            # prompt = restriction + " " + question
            
            prompt = question + "Output only the final answer itself. Do not add <>, quotes, or any extra text."
            # prompt = question
            prompt = instructions_part + description_part + " " + prompt

            if self.prompt_mode == "question_only":
               prompt = question

        elif textInput == "multiple_choice_question":
            mc1, mc2, mc3, mc4 = row["mc1"], row["mc2"], row["mc3"], row["mc4"]
            multipleChoice = []
            for mc in [mc4,mc3,mc2,mc1]:
                if mc != "" and mc != "Skip" and isinstance(mc, str):
                    multipleChoice.append(mc)
            mcString = ", ".join(multipleChoice)

            restriction = "Your answer must be one of the choices provided. You must think step by step internally, but do not output your reasoning. Only output the final answer."
            prompt = restriction + " " + question + " " + "Choices: " + mcString + "."

            prompt = instructions_part + description_part + " " + prompt

            if self.prompt_mode == "question_only":
               prompt = question + " " + restriction + " " + "Choices: "  + mcString + "."

        if self.agentType == "GPT-4o":
            promptPrefix = "Question: "
            promptSuffix = "\nAnswer:"
        elif self.agentType == "GPT-5":
            promptPrefix = "Question: "
            promptSuffix = "\nAnswer:"
        elif self.agentType == "Salesforce/blip2-opt-2.7b":
            promptPrefix = "Question: "
            promptSuffix = " Answer:"
        elif self.agentType == "Salesforce/blip2-opt-6.7b":
            promptPrefix = "Question: "
            promptSuffix = " Answer:"
        elif self.agentType == "Salesforce/blip2-flan-t5-xxl":
            promptPrefix = "Question: "
            promptSuffix = "\nAnswer:"
        elif self.agentType == "Salesforce/blip2-flan-t5-xl":
            promptPrefix = "Question: "
            promptSuffix = "\nAnswer:"           
        elif (self.agentType == "llava-hf/llava-1.5-7b-hf" or self.agentType == "llava-hf/llava-1.5-13b-hf"):
            promptPrefix = "USER: <image>\n"
            promptSuffix = "\nASSISTANT:"
        elif (self.agentType == "liuhaotian/llava-v1.6-34b" or 
              self.agentType == "liuhaotian/llava-v1.6-vicuna-13b" or 
              self.agentType == "liuhaotian/llava-v1.6-mistral-7b"):
            promptPrefix = "USER: "
            promptSuffix = "\nASSISTANT:"
        elif (self.agentType == "google/pix2struct-chartqa-base" or 
               self.agentType == "google/matcha-chartqa"):
            promptPrefix = "Question: "
            promptSuffix = " Answer:"

        # ykc changed all prompt here to avoid the duplicate instructions
        if self.promptType == "indist_instructions_question":
            # prompt = promptPrefix + self.instructions + " " + prompt + promptSuffix

            # new change
            prompt = promptPrefix + " " + prompt + promptSuffix
            # new change

            if (self.agentType == "google/deplot"):
                prompt = "Generate underlying data table of the figure below:"

        elif self.promptType == "indist_instructions_cot_0shot_question":
            cot_0shot = " Let's think step by step."
            # prompt = promptPrefix + self.instructions + " " + prompt + promptSuffix + cot_0shot
            
            # new change
            prompt = promptPrefix + " " + prompt + promptSuffix + cot_0shot
            # new change


        elif self.promptType == "instructions_question":
            # prompt = self.instructions + " " + prompt

            prompt = prompt

            if (self.agentType == "llava-hf/llava-1.5-7b-hf" or self.agentType == "llava-hf/llava-1.5-13b-hf"):
                prompt = "<image>\n" + prompt

        elif self.promptType == "incontext_instructions_question":
            if self.testType.find("chartqa") != -1:
                incontext_examples = [
                    {
                        "image_url": 'https://data-visualization-benchmark.s3.us-west-2.amazonaws.com/chartqa-val/images/multi_col_133.png',
                        "question": 'How many people are forecast to be occasional viewers of eSports by 2024?',
                        "answer": '291.6'
                    },
                    {
                        "image_url": 'https://data-visualization-benchmark.s3.us-west-2.amazonaws.com/chartqa-val/images/two_col_100022.png',
                        "question": 'What was the second-most-shared news page on Facebook in January 2017?',
                        "answer": 'CNN'
                    },
                    {
                        "image_url": 'https://data-visualization-benchmark.s3.us-west-2.amazonaws.com/chartqa-val/images/two_col_6132.png',
                        "question": 'How many widowed people lived in Canada in 2000?',
                        "answer": '1.55'
                    },
                    {
                        "image_url": 'https://data-visualization-benchmark.s3.us-west-2.amazonaws.com/chartqa-val/images/two_col_1365.png',
                        "question": 'What percentage of people infected with the coronavirus were female?',
                        "answer": '51.1'
                    }
                ]

                if self.agentType.find("llava") != -1:
                    ex1 = "USER: <image>\n Q: " + incontext_examples['question'][0] + " A: ASSISTANT: " + incontext_examples[0]["answer"] + "." 
                    ex2 = "USER: <image>\n Q: " + incontext_examples['question'][1] + " A: ASSISTANT: " + incontext_examples[1]["answer"] + "." 
                    ex3 = "USER: <image>\n Q: " + incontext_examples['question'][2] + " A: ASSISTANT: " + incontext_examples[2]["answer"] + "." 
                    ex4 = "USER: <image>\n Q: " + incontext_examples['question'][3] + " A: ASSISTANT: " + incontext_examples[3]["answer"] + "." 
                    intstruction = "Following these examples, please answer the following question using either a word or a number."
                    prefix = "Q:"
                    suffix = "A: ASSISTANT:"
                    prompt = f"{ex1} {ex2} {ex3} {ex4} {intstruction} {prefix} {prompt} {suffix}"
                    return prompt, incontext_examples
                elif self.agentType == "GPT-4o" or self.agentType == "GPT-5":
                    incontext_examples = [
                        {
                            "image_url": 'https://data-visualization-benchmark.s3.us-west-2.amazonaws.com/chartqa-test/chartqa_incontext.png'
                        }
                    ]
                    system_message = "Suppose that you are an expert in data analysis and visualization." 
                    ex = "The first image is titled Examples. Following the examples shown in the first image, please answer the following question about the second image, using either a word or a number."
                    prefix = "Q:"
                    prompt = f"{system_message} {ex} {prefix} {prompt}"
                    return prompt, incontext_examples
        else:
            return None
            
        return prompt, None, instructions_part, description_part

