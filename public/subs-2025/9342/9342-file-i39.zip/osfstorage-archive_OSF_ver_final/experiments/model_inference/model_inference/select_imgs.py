import os

imgs_dir = 'D:\\osu\\osu\\OSU\\OSU\\2025summer\\projects\\downloaded_data\\images'
imgs_names_dir = 'D:\\osu\\osu\\OSU\\OSU\\2025summer\\projects\\osfstorage-archive_OSF_ver\\experiments\\model_inference\\model_inference\\samples\\'
names = ["calvi-standard.txt", "calvi-trick.txt", "ggr.txt", "holf.txt", "holf2.txt", "vlat.txt"]

for curr_name in names:
    with open(os.path.join(imgs_names_dir, curr_name), 'r') as f:
        lines = f.readlines()
    lines = [line.strip() for line in lines]
    # print(f"{curr_name}: {len(lines)}")
    print(lines)

print(imgs_names_dir)