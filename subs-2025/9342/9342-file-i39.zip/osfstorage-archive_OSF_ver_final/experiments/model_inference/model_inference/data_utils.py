import requests
import pandas as pd
from PIL import Image
import os

class DataUtils:
    @staticmethod
    def fetch_instructions(testType):
        try:
            url = f"https://data-visualization-benchmark.s3.us-west-2.amazonaws.com/{testType}/instructions.txt"
            return requests.get(url).text
        except requests.RequestException as e:
            print(f"Error fetching {url}: {e}")
            return None

    @staticmethod
    def fetch_questions(testType):
        try:
            url = f"https://data-visualization-benchmark.s3.us-west-2.amazonaws.com/{testType}/questions.csv"
            return pd.read_csv(url)
        except Exception as e:
            print(f"Error loading questions from {url}: {e}")
            return pd.DataFrame()

    @staticmethod
    def post_data(data):
        try:
            url = 'https://foraes.com/api/v1/prompt'
            response = requests.post(url, json=data)
            return response
        except requests.RequestException as e:
            return None

    @staticmethod
    def get_image(url):
        try:
            return Image.open(requests.get(url, stream=True).raw).convert('RGB')
        except requests.RequestException as e:
            return None
    

    @staticmethod
    def save_file(results, prompt_mode, agentType, testType, base_dir=None):
        """
        results: list of dicts
        prompt_mode: str, e.g. "paper"
        agentType: str, e.g. "google/pix2struct-chartqa-base"
        testType: str, e.g. "ggr"
        base_dir: str, optional, base directory to save results
        """

        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        if base_dir is None:
            base_dir = os.path.join(root_dir, "prompt_outputs")
        model_dir = agentType.replace("/", "-")
        save_dir = os.path.join(base_dir, prompt_mode, model_dir)
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, f"{testType}_results.csv")
        df = pd.DataFrame(results)
        df.to_csv(save_path, index=False, encoding="utf-8")
        print(f"Saved results to {save_path}")
